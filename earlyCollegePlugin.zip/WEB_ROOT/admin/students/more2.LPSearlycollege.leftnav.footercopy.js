<script type="text/javascript">

$j(document).ready(function() {
    // Find the link to the state page
    $j("ul#std_information > li > a[href^='state/stateMA.html?frn=']") 
        // Get the student FRN
        .parent()
        // Find the next sibling
        .after(
            // Add a new link to the early college page
            $j('<li><a href="LPS-earlycollege.html?frn=~(studentfrn)">STATE EARLY COLLEGE &tilde;</a></li>')
        );
});

</script>